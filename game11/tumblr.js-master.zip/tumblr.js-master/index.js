var tumblr = require('./lib/tumblr');
tumblr.request(require('request'));

module.exports = tumblr;
