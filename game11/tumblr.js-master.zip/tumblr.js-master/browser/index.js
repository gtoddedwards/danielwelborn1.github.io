var tumblr = require('../lib/tumblr');
tumblr.request(require('browser-request'));

module.exports = tumblr;
